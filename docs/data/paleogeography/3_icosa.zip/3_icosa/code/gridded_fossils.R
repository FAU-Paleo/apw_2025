# Exercise: Distribution of fossil occurrences with icosa:
# Erlangen, 2025
# Ádám T. Kocsis
# CC-BY (attribution)

# Instruction: plot a map of the density of fossil occurrences in the PBDB in ~5 degree geographic grid cells

# set working directory
setwd("3_icosa/")

# pay attention to directory structure, or you will suffocate in files very fast!
dir.create("export", showWarnings=FALSE)
dir.create("data", showWarnings=FALSE)
dir.create("data/chronosphere", showWarnings=FALSE)

# required packages
library(icosa)
library(chronosphere)
library(viridis)

########################################----------------------------------------
# 1. Access the data
# download most of the pbdb
pbdb <- chronosphere::fetch("pbdb", ver="20250819", datadir="data/chronosphere")

# get the Corals from the Pleistocene
# 1. corals
dat <- pbdb[which(pbdb$order=="Scleractinia"), ]

# 2. the Pleistocene subset
table(dat$time_contain)
dat <- dat[which(dat$time_contain%in%c("Late Pleistocene", "Calabrian", "Chibanian", "Gelasian")), ]

# download a map to plot on
land <- chronosphere::fetch("NaturalEarth", verbose=FALSE, datadir="data/chronosphere")

# plot the occurrences
plot(land$geometry, col="gray", border=NA)
points(dat$lng, dat$lat, pch=3, col="red")

########################################----------------------------------------
# 2. Grid the occurrences - Discretization
# create a penta-hexagonal grid, with 5-degree edge length.
# sf=TRUE indicates that we want a plottable, 2d projection as well.
hex <- hexagrid(deg=5, sf=TRUE)

# plotting the grid on top
plot(hex, add=TRUE, border="lightgray")

# we can visualize the names of the grid cells as well
icosa::gridlabs(hex, cex=0.8)

# The actual discretization: looking up where the occurrences are and
# adding the cell column
dat$cell <- locate(hex,dat[,c("lng", "lat")] )

# tabulating the number of occurrences in a cell
nOccs <- table(dat$cell)

# visualize - default plotting
plot(hex, nOccs, reset=FALSE)
plot(land$geometry, col="#aaaaaaaa", border=NA, add=TRUE)



########################################----------------------------------------
# 3. Calculate richness in a cell (face-value)

#' Calculate the number of categories in a vector
#'
#' @param x The vector
#' @return A single integer
#' @examples
#' richness(c("a", "b", "a", "d", "c", "c"))
richness <- function(x) length(levels(factor((x))))

# apply this to the data
# INDEX: repeat for every cell level
# X: Repeat on the genus entries
# FUN: how many different entries are in X, at different values of INDEX?
nGen <- tapply(X=dat$genus, INDEX=dat$cell, FUN=richness)


# a more complex plot
# a. create a color palette at specific breaks (transparent)
# rounding off to the closest 10-divisible number
breaks <- seq(0, ceiling(max(nGen)/10)*10, by=10)
cols <- viridis::viridis(length(breaks)-1, alpha=0.75)


# b. visualize
# the number of genera with the heatmap legend
plot(hex, nGen, reset=FALSE, border="gray90", breaks=breaks, pal=cols)
# land
plot(land$geometry, col="gray", border=NA, add=TRUE)
# again the number of genera
plot(hex, nGen, add=TRUE, border="gray90", breaks=breaks, pal=cols)
# occurrence records
points(dat$lng, dat$lat, pch=3, col="red")

# be aware that sampling a cell very much affects the richness estimate!
cor.test(nGen, nOccs, method="spearman")

# access the latitudes of the sampled cells
# centers(hex) returns all cells' longitude and latitude values as a matrix.
# cell names are in rownames
cellLatitude <- icosa::centers(hex)[names(nGen),"lat"]

# the Latitudinal pattern of richness in a cells
cellInfo <- data.frame(
	latitude=cellLatitude,
	richness=nGen
)

# close previous device before starting!
dev.off()
plot(cellInfo$latitude,
	cellInfo$richness,
	xlim=c(-90, 90),
	xlab="Latitude (°)",
	ylab="Number of genera",
	axes=FALSE,
	pch=16,
	col="#005599")


axis(1, at=seq(-90, 90, 30))
axis(2)
