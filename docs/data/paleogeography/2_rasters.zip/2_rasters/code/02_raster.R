# Basic raster data examples
# Erlangen, 2024
# Ádám T. Kocsis
# CC-BY (attribution)
setwd("2_rasters/")

# necessary packages
library(viridis) # color palette
library(terra) # actual
library(divDyn) # fossils
library(sf) # interactions between

# 0. primer: The volcano data
data(volcano)
str(volcano)
?volcano

# plotting such a data 
contour(volcano)
filled.contour(volcano, col=viridis(25))


# visualize the areas that are above 150m!
bVolcano <- volcano > 150
contour(bVolcano)

# removing values
volcano2 <- volcano
volcano2[!bVolcano] <- NA
filled.contour(volcano2, col=viridis(25))

# visualize the areas that are above 150m - with plotting only
filled.contour(volcano, col=viridis(25), zlim=c(150, 200))


################################################################################
# 1. Raster data - single layer
# reading in a file, instantiate a raster object. raster::raster()
etopo1 <- rast("data/ETOPO1/ETOPO1_ice_c_20110606_tiff_1.tif")
etopo1

# crs as WKT
cat(terra::crs(etopo1))

# basic attributes - raster::res(), raster::xres(), raster::yres()
terra::res(etopo1)
terra::xres(etopo1)
terra::yres(etopo1)

# the extent - raster::extent()
terra::ext(etopo1)
terra::ext(etopo1)[2]

dim(etopo1)

# plotting
plot(etopo1)

# fully custommized plot
plot(etopo1
	, xlim=c(-45, 45) # limits to plotting
	, ylim=c(-45, 45) # y limit to plotting
	, col=inferno(7) # color palette
	, axes=FALSE # an axes
	, main="This is a plot"
)
plot(etopo1, col=rainbow(256))

# Overplotting something e.g. the corals
data(corals)
colls <- unique(corals[, c("collection_no", "lng", "lat")])

# as regular points
plot(etopo1)
points(colls[, c("lng", "lat")]
	, pch=3
	, col="red"
)

# Cropping: Changing the extent of the raster 
ex <- terra::ext(
	c(
		xmin=-45,
		xmax=+45,
		ymin=-30, 
		ymax=30
	)
)

# the actual cropping raster::crop()
cropped<- terra::crop(etopo1, ex)
plot(cropped)

################################################################################
# Exercise
# Create a topographic map of Europe using the crop function!
################################################################################
# this is different here... do not set extent manually!
wrong<- etopo1
terra::ext(wrong) <- c(30, 40, 10, 67)
plot(wrong)

# Changing raster resolution: deletes data!
wrong<- etopo1
terra::res(wrong) <- c(0.5,0.5)
terra::res(wrong) <- c(2,2)

# 1A. Aggregation: decrease resolution by combining cells, raster::aggregate()
aggregated <- terra::aggregate(etopo1, 2)
aggregated <- terra::aggregate(etopo1, 10)
plot(aggregated)

# 1B. Disaggregation: increase resolution by splitting cells, raster::disaggregate()
disaggregated <- terra::disagg(etopo1, 4)
plot(disaggregated)

# 2A. Resampling
# increase resolution (smoothing)
# Step 1: define a raster object. 
target <- terra::rast(res=c(0.2, 0.2))

# Step 2: actual resampling
retopo1 <- terra::resample(etopo1, target, method="bilinear")
plot(retopo1)

# decrease resolution, same steps
target <- terra::rast(res=c(4.3, 4.3))
retopo1 <- terra::resample(etopo1, target)
suppressWarnings(plot(retopo1))

# Projection change
et1Moll <- terra::project(etopo1, "ESRI:54009")
et1Moll
plot(et1Moll)

# missing values outside the projection!
valsMoll<- terra::values(et1Moll)

# the proportion of missing values
sum(is.na(valsMoll))/terra::ncell(et1Moll)

################################################################################
# Exercise!
# Make a histogram of the values!
################################################################################

################################################################################
# Exercise!
# Plot the ETOPO1 raster using Sinusoidal projection,
# Import Natural Earth Land polygons,  Plot it on top of the raster!
################################################################################

################################################################################
# Exercise: 
# Compare two resampling methods: bilinear and cubic at the target resolution of 0.2!
# Calculate the difference between the rasters
# What is the mean? The mean of the absolute values? Plot a histogram!
################################################################################

# Rasterization: iteration based on raster structure.
# eg. Count the number of items in cells

# iteration based on a 10 by 10 degree grid.
# The results will have a value in every grid cell
grid <- terra::rast(res=c(10, 10))

# by default rasterization works on a dummy index vector
# The function returns the length of this dummy vector
rasted <- terra::rasterize(
	x=as.matrix(colls[, c("lng", "lat")]), 
	y= grid, 
	fun=length)

# the density of occurrences
plot(rasted, col=viridis::viridis(256))
points(colls[, c("lng", "lat")]
	, pch=3
	, col="red"
)

# How to calculate the number of occurrences? 
# tabule the number of occurrences in every collection
# and add it to the collections table
colls$nOccs <- table(corals$collection_no)[as.character(colls$collection_no)]

# Same as earlier
# Now we provide an actual vector (same length as nrow(x))
# But we still only execute length on it: the result is the
# same as earlier.
rasted2 <- terra::rasterize(
	x=as.matrix(colls[, c("lng", "lat")]), 
	values=colls$nOccs, 
	y= grid, 
	fun=length)

# we actually want to calculate the sum of the values' subset
# the is in the grid cell!
occsPerCell <- terra::rasterize(
	x=as.matrix(colls[, c("lng", "lat")]), 
	values=colls$nOccs, 
	y= grid, 
	fun=sum)

# creat a plot comparing the two
x11() # windows()/quartz()... 
par(mfrow=c(2,1)) # two rows, one column of plots
plot(rasted, main="Number of collections")
plot(occsPerCell,  main="Number of occurrences")

################################################################################
# II. Interaction with vector data!
# Read in the coutnries data 
countries <- sf::st_read("data/world_admin/world-administrative-boundaries.shx")

# simple overplotting
plot(etopo1)
plot(countries$geometry, col=NA, border="black", add=TRUE)

# masking with countries - show values under the polygons
countryElev <- terra::mask(etopo1, countries)
plot(countryElev)

# one country's elevation
canada <- countries[which(countries$name=="Canada"),]

# the country on its own
plot(canada$geometry, col="red")

# the entire topography with country's outlie
plot(etopo1)
plot(canada$geometry, add=TRUE)

# the masked topography
oneElev <- terra::mask(etopo1, canada)
plot(oneElev)

# Mean of values? 
# correct from implementation point of view, but latitudinal patterns might be a problem!
canadaVals <- terra::values(oneElev)  
mean(canadaVals, na.rm=T)

################################################################################
# Exercise: 
# Calculate the mean elevation of all countries!
########################################----------------------------------------


################################################################################
# Multi-layer raster: WorldClim daa
wcFiles <- list.files("data/WorldClim")
wc <- terra::rast(file.path("data/WorldClim",wcFiles))
plot(wc)

# extracting values
erlangen <- matrix(c(10.97, 49.58),  ncol=2)
terra::extract(etopo1, erlangen)

# average values
terra::extract(wc, erlangen)

# single layer: bio1: Mean Annual Temperature in deg C
bio1 <- wc[[1]]
bio1 <- wc[["wc2.1_10m_bio_1"]]

# extract value from this raster
terra::extract(bio1, erlangen)
plot(bio1)

################################################################################
# III: Lower-level operations interaction
# replacing values, only above 1000m level
high<- etopo1
terra::values(high)[terra::values(high)<1000] <- NA
plot(high)

# Corresponding climate: have to resample the raster to match!
bio1Re <- terra::resample(bio1, high)
bio1High <- terra::mask(bio1Re, high)
plot(bio1High)

################################################################################
# Climate averaging
# Latitude averaging
# Canada's temperature
oneBio1<- terra::mask(bio1, canada)
plot(oneBio1)

# doing this in long-lat (wrong, polar areas are overrepresented!)
canadaVals <- terra::values(oneBio1)  
mean(canadaVals, na.rm=T)

# in equal-area projection (correct)
oneBio1<- terra::project(oneBio1, "ESRI:54009")
canadaVals <- terra::values(oneBio1)  
mean(canadaVals, na.rm=T)

###############################################################################
# Getting x and y coordinates from the rasters
xy <- terra::xyFromCell(etopo1, 1:terra::ncell(etopo1))
xyz <- cbind(xy, terra::values(etopo1))

################################################################################
# Exercise: 
# Write out the high-area temperatures (bio1High) into a file!
# Search for a function to write the raster on the hard drive!
# Write out the raster (tiff)!
################################################################################


################################################################################
# Exercise: 
# 1. Calculate the mean annual surface air temperature of every country! (1st Bioclimatic variable)
# needed objects:
# countries, bio1


