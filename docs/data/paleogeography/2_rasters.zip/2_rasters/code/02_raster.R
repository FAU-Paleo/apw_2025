# Basic raster data examples
# Erlangen, 2024
# Ádám T. Kocsis
# CC-BY (attribution)
setwd("/mnt/sky/Dropbox/Teaching/Workshops/2024-08-05_APW2024/material/paleogeography/2_rasters/")

# necessary packages
library(viridis) # color palette
library(terra) # actual
library(divDyn) # fossils
library(sf) # interactions between

# 0. primer: The volcano data
data(volcano)
str(volcano)
?volcano

# plotting such a data 
contour(volcano)
filled.contour(volcano, col=viridis(25))


# visualize the areas that are above 150m!
bVolcano <- volcano > 150
contour(bVolcano)

# removing values
volcano2 <- volcano
volcano2[!bVolcano] <- NA
filled.contour(volcano2, col=viridis(25))

# visualize the areas that are above 150m - with plotting only
filled.contour(volcano, col=viridis(25), zlim=c(150, 200))


################################################################################
# 1. Raster data - single layer
# reading in a file, instantiate a raster object. raster::raster()
etopo1 <- rast("data/ETOPO1/ETOPO1_ice_c_20110606_tiff_1.tif")
etopo1

# crs as WKT
cat(terra::crs(etopo1))

# basic attributes - raster::res(), raster::xres(), raster::yres()
terra::res(etopo1)
terra::xres(etopo1)
terra::yres(etopo1)

# the extent - raster::extent()
terra::ext(etopo1)
terra::ext(etopo1)[2]

dim(etopo1)

# plotting
plot(etopo1)

# fully custommized plot
plot(etopo1
	, xlim=c(-45, 45) # limits to plotting
	, ylim=c(-45, 45) # y limit to plotting
	, col=inferno(7) # color palette
	, axes=FALSE # an axes
	, main="This is a plot"
)
plot(etopo1, col=rainbow(256))

# Overplotting something e.g. the corals
data(corals)
colls <- unique(corals[, c("collection_no", "lng", "lat")])

# as regular points
plot(etopo1)
points(colls[, c("lng", "lat")]
	, pch=3
	, col="red"
)

# Cropping: Changing the extent of the raster 
ex <- terra::ext(
	c(
		xmin=-45,
		xmax=+45,
		ymin=-30, 
		ymax=30
	)
)

# the actual cropping raster::crop()
cropped<- terra::crop(etopo1, ex)
plot(cropped)

################################################################################
# -> Exercise 1
################################################################################

# this is different here... do not set extent manually!
wrong<- etopo1
terra::ext(wrong) <- c(30, 40, 10, 67)
plot(wrong)

# Changing raster resolution: deletes data!
wrong<- etopo1
terra::res(wrong) <- c(0.5,0.5)
terra::res(wrong) <- c(2,2)

# 1A. Aggregation: decrease resolution by combining cells, raster::aggregate()
aggregated <- terra::aggregate(etopo1, 2)
aggregated <- terra::aggregate(etopo1, 10)
plot(aggregated)

# 1B. Disaggregation: increase resolution by splitting cells, raster::disaggregate()
disaggregated <- terra::disagg(etopo1, 4)
plot(disaggregated)

# 2A. Resampling
# increase resolution (smoothing)
# Step 1: define a raster object. 
target <- terra::rast(res=c(0.2, 0.2))

# Step 2: actual resampling
retopo1 <- terra::resample(etopo1, target, method="bilinear")
plot(retopo1)

# decrease resolution, same steps
target <- terra::rast(res=c(4.3, 4.3))
retopo1 <- terra::resample(etopo1, target)
plot(retopo1)
# suppressWarnings(plot(retopo1))

# Projection change
et1Moll <- terra::project(etopo1, "ESRI:54009")
et1Moll
plot(et1Moll)

# missing values outside the projection!
valsMoll<- terra::values(et1Moll)

# the proportion of missing values
sum(is.na(valsMoll))/terra::ncell(et1Moll)


################################################################################
# -> Exercise 2, 3
################################################################################



# Rasterization: iteration based on raster structure.
# eg. Count the number of items in cells

# iteration based on a 10 by 10 degree grid.
# The results will have a value in every grid cell
grid <- terra::rast(res=c(10, 10))

# by default rasterization works on a dummy index vector
# The function returns the length of a dummy vector
rasted <- terra::rasterize(
	x=as.matrix(colls[, c("lng", "lat")]), 
	y= grid, 
	fun=length)

# the density of occurrences
plot(rasted, col=viridis::viridis(256))
points(colls[, c("lng", "lat")]
	, pch=3
	, col="red"
)

# How to calculate the number of occurrences? 
# tabule the number of occurrences in every collection
# and add it to the collections table
colls$nOccs <- table(corals$collection_no)[as.character(colls$collection_no)]

# Now we provide an actual vector (same length as nrow(x))
# But if we still only execute length on it: the result is the
# same as earlier:
rasted2 <- terra::rasterize(
	x=as.matrix(colls[, c("lng", "lat")]), 
	values=colls$nOccs, 
	y= grid, 
	fun=length) # wrong

# we actually want to calculate the sum of the values' subset
# the is in the grid cell!
occsPerCell <- terra::rasterize(
	x=as.matrix(colls[, c("lng", "lat")]), 
	values=colls$nOccs, 
	y= grid, 
	fun=sum) # good

# creat a plot comparing the two
x11() # windows()/quartz()... 
par(mfrow=c(2,1)) # two rows, one column of plots
plot(rasted, main="Number of collections")
plot(occsPerCell,  main="Number of occurrences")

################################################################################
# II. Interaction with vector data
# Read in the coutnries data 
countries <- sf::st_read("data/world_admin/world-administrative-boundaries.shx")

# simple overplotting
plot(etopo1)
plot(countries$geometry, col=NA, border="black", add=TRUE)

# masking with countries - show values under the polygons
countryElev <- terra::mask(etopo1, countries)
plot(countryElev)

# one country's elevation
canada <- countries[which(countries$name=="Canada"),]

# the country on its own
plot(canada$geometry, col="red")

# the entire topography with country's outlie
plot(etopo1)
plot(canada$geometry, add=TRUE)

# the masked topography
oneElev <- terra::mask(etopo1, canada)
plot(oneElev)

# Mean of values? 
# correct from implementation point of view, but latitudinal patterns might be a problem!

canadaVals <- terra::values(oneElev)  
mean(canadaVals, na.rm=T)

################################################################################
# -> Exercise 4
################################################################################


# Multi-layer raster: WorldClim daa
wcFiles <- list.files("data/WorldClim")
wc <- terra::rast(file.path("data/WorldClim",wcFiles))
plot(wc)

# extracting values
erlangen <- matrix(c(10.97, 49.58),  ncol=2)
terra::extract(etopo1, erlangen)

# average values
terra::extract(wc, erlangen)

# single layer: bio1: Mean Annual Temperature in deg C
bio1 <- wc[[1]]
bio1 <- wc[["wc2.1_10m_bio_1"]]

# extract value from this raster
terra::extract(bio1, erlangen)
plot(bio1)

################################################################################
# III: Lower-level operations interaction
# replacing values, only above 1000m level
high<- etopo1
terra::values(high)[terra::values(high)<1000] <- NA
plot(high)

# Corresponding climate: have to resample the raster to match!
bio1Re <- terra::resample(bio1, high)
bio1High <- terra::mask(bio1Re, high)
plot(bio1High)

################################################################################
# Climate averaging
# Latitude averaging
# Canada's temperature
oneBio1<- terra::mask(bio1, canada)
plot(oneBio1)

# doing this in long-lat (wrong, polar areas are overrepresented!)
canadaVals <- terra::values(oneBio1)  
mean(canadaVals, na.rm=T)

# in equal-area projection (correct)
oneBio1<- terra::project(oneBio1, "ESRI:54009")
canadaVals <- terra::values(oneBio1)  
mean(canadaVals, na.rm=T)

# Getting x and y coordinates from the rasters
xy <- terra::xyFromCell(etopo1, 1:terra::ncell(etopo1))
xyz <- cbind(xy, terra::values(etopo1))

################################################################################
# -> Exercise 5, 6
################################################################################





















################################################################################
# Exercises
################################################################################

########################################----------------------------------------
# Exercise 1. Create a topographic map of North America using the crop function!
########################################----------------------------------------

########################################----------------------------------------
# Exercise 2. Plot the ETOPO1 raster using (Lambert's) Cylindrical Equal Area projection,
# + Import Natural Earth Land polygons,  plot it on top of the raster!
########################################----------------------------------------

########################################----------------------------------------
# Exercise 3. Compare two resampling methods: bilinear and cubic at the target resolution of 0.2!
# Calculate the difference between the rasters!
# What is the mean? The mean of the absolute values? Plot a histogram!
# What areas are most affected?
########################################----------------------------------------

########################################----------------------------------------
# Exercise 4. Calcualte the mean elevation of all countries!
# Based on this code:
i<- 154
# get the focal country
oneCountry <- countries[i,]
# mask the elevation values out
oneElev <- terra::mask(etopo1, oneCountry)
# plot(oneElev)
# plot(oneCountry$geometry, add=TRUE)
# grab the values from the raster
oneValues <- terra::values(oneElev)
# calculate mean
mean(oneValues, na.rm=T)
#  Write a for loop to iterate the mean elevation calculation and store it in a field (column)
########################################----------------------------------------

########################################----------------------------------------
# Exercise 5. Write out the high-area temperatures (bio1High) into a file!
# - Search for a function to write the raster on the hard drive!
# - Write out the raster (tiff)!
########################################----------------------------------------

########################################----------------------------------------
# Exercise 6. Calculate the mean annual surface air temperature of every country!
# - (1st Bioclimatic variable)
########################################----------------------------------------




























################################################################################
# Solutions
################################################################################

########################################----------------------------------------
# Exercise 1
########################################----------------------------------------
plot(etopo1)

# extent from map:
naExt <- ext(c(
	-177.37375,
	-41.40821,
	3.622898,
	86.758862))

# do the cropping
na <- crop(etopo1, naExt)
plot(na)

########################################----------------------------------------
# Exercise 2
########################################----------------------------------------

# project etopo1
etCEA <- terra::project(etopo1, "ESRI:54034")
plot(etCEA)

# the Natural Earth Land polygons (v0.4.1)
ne<- chronosphere::fetch("NaturalEarth", "land", ver="4.1.0")
#ne <- st_read("/home/adam/Desktop/ces-data/1_vectors/data/natural_earth/ne_10m_land.shx")

# transform and plot
neCEA <- st_transform(ne, "ESRI:54034")
plot(etCEA)
plot(neCEA$geometry, add=TRUE, col="#FF000044", border=NA)


########################################----------------------------------------
# Exercise 3
########################################----------------------------------------

# template
target <- terra::rast(res=c(0.2, 0.2))

# the two resampling methods
bilinear <- terra::resample(etopo1, target, method="bilinear")
cubic <- terra::resample(etopo1, target, method="cubic")

# the difference between the values
diff <- bilinear-cubic
plot(diff)

# some stats and descriptors
mean(values(diff))
hist(values(diff), breaks=200)
mean(abs(values(diff)))
plot(abs(etopo1))

# high-gradient areas are most affected.

########################################----------------------------------------
# Exercise 4
########################################----------------------------------------

# 1. Create a vector container to store all countries' mean elevation
meanElevs <- rep(NA, nrow(countries))

# 2. Write a for loop to iterate the mean elevation calculation and store it in
# For quick checking: create a pdf to plot all plots
# If masking is done right, calculating the mean of the values should be no problem!
dir.create("export", showWarnings=FALSE)
pdf("export/countryElevations.pdf", height=10, width=20)

# in the container. (if there is no value in a country, ignore it!)
#for(i in 1:5){ # good idea to prototype with a few!
for(i in 1:nrow(countries)){

# 	i<- 154
	# get the focal country
	oneCountry <- countries[i,]
	# mask the elevation values out
	oneElev <- terra::mask(etopo1, oneCountry)
	plot(oneElev)
	plot(oneCountry$geometry, add=TRUE)
	# grab the values from the raster
	oneValues <- terra::values(oneElev)
	# calculate mean
	meanElevs[i] <- mean(oneValues, na.rm=T)
	# loop
	cat(i, "\r")
	flush.console()
}

# Need to close the pdf. Until that it is not readable
dev.off()

# Visualize it with a choropleth map!
# - add the container to the countries object as a new column (field/attribute)
countries$meanElev <-meanElevs

# plotting
breaks <- c(-10000, -500, 0, 100, 200, 300, 500, 700, 900, +10000)
# - plot the new variable!
plot(countries["meanElev"], breaks=breaks, pal=viridis(length(breaks)-1))


########################################----------------------------------------
# Exercise 5
########################################----------------------------------------
dir.create("export", showWarnings=FALSE)
writeRaster(bio1High, filename="export/bio1High.tif")

# check reading it in!
re_read <- rast("export/bio1High.tif")
re_read - bio1High


########################################----------------------------------------
# Exercise 6
########################################----------------------------------------

# Transform everything to an equal area projection
countriesMoll <- st_transform(countries, "ESRI:54009")
bio1Moll <- project(bio1, "ESRI:54009")

plot(bio1Moll)
plot(countriesMoll$geometry, add=TRUE)

# 1. Create a vector container to store all countries' mean temperature
meanTemp <- rep(NA, nrow(countriesMoll))

# 2. Write a for loop to iterate the mean elevation calculation and store it in
pdf("export/countryTemperatures.pdf", height=10, width=20)
# in the container. (if there is no value in a country, ignore it!)
# Takes ~5-10 minutes!
for(i in 1:nrow(countriesMoll)){

# 	i<- 154
	# get the focal country
	oneCountry <- countriesMoll[i,]
	# mask the temperatures values out
	oneTemp <- terra::mask(bio1Moll, oneCountry)
	plot(oneTemp)
	plot(oneCountry$geometry, add=TRUE)
	# grab the values from the raster
	oneValues <- terra::values(oneTemp)
	# calculate mean
	meanTemp[i] <- mean(oneValues, na.rm=T)
	# loop
	cat(i, "\r")
	flush.console()
}

# finish the plot
dev.off()


# what is wrong with the variables that have temperature?
# They do not have info in the raster!!!
pdf("export/examine.pdf", width=20, height=10)
	plot(bio1Moll)
	plot(countriesMoll[is.nan(meanTemp), ]$geometry, add=TRUE)
dev.off()


# works both with transformed and original projection
countriesMoll$temp <- meanTemp
countires$temp <- meanTemp

# Visualize the result
plot(countries["temp"])
